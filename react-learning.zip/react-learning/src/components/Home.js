import React from "react";

function Home() {
    return <h1>Welcome to The Home Page</h1>
}

export default Home;